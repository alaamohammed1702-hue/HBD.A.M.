
import React, { useState } from 'react';
import { generateRomanticReason } from '../services/geminiService';

const LoveNotesGenerator: React.FC = () => {
  const [message, setMessage] = useState<string>("اضغط على القلب يقلبي...");
  const [loading, setLoading] = useState(false);

  const fetchNewMessage = async () => {
    setLoading(true);
    const newMessage = await generateRomanticReason("عمار");
    setMessage(newMessage);
    setLoading(false);
  };

  return (
    <div className="max-w-xl mx-auto my-16 text-center px-4">
      <div className="relative group cursor-pointer" onClick={!loading ? fetchNewMessage : undefined}>
        <div className={`text-9xl transition-all duration-500 ${loading ? 'animate-ping' : 'hover:scale-110 active:scale-90'}`}>
          ❤️
        </div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-white font-bold text-lg pointer-events-none whitespace-nowrap">
          {loading ? 'لحظة..' : 'احبك كتكوتي'}
        </div>
      </div>
      
      <div className="mt-8 bg-white p-6 rounded-2xl shadow-lg border-2 border-dashed border-rose-300 relative">
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-rose-500 text-white px-4 py-1 rounded-full text-xs font-bold">
          حجي من القلب
        </div>
        <p className={`text-xl font-romantic text-gray-800 leading-relaxed italic ${loading ? 'opacity-50' : 'opacity-100'}`}>
          "{message}"
        </p>
      </div>
      <p className="mt-4 text-rose-400 text-sm font-bold">كل ضغطة تطلّع رسالة ✨</p>
    </div>
  );
};

export default LoveNotesGenerator;
